# WaBot-VendasSSH
🔥Feito por:
https://t.me/MegahBox

👥Canal do telegram:
https://t.me/cursov2ray

🤖Bot de teste:
https://wa.me/559191288339

Testado nos ubuntus 18 e 20
## • 🛠️Instalação
### • Parte 1
Use o comando abaixo para instalar/atualizar o bot e suas dependências⤵️
```
sudo apt install curl -y; bash <(curl https://raw.githubusercontent.com/endblack/WaBot-VendasSSH/main/install.sh)
```
### • Parte 2
Use o comando abaixo para mudar a versão do nodejs⤵️
```
wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
```
Após colocar o comando, saia da vps e entre novamente, em seguida coloque o comando abaixo ⤵️
```
nvm install 16
```

### • 👨‍🏫Instruções
Após terminar a instalação, digite o comando `qrcode` e leia o Qrcode que irá aparecer no terminal, após ler o Qrcode espere uns 5 segundos e dê um CTRL+c para sair desta parte, agora digite `onbot` para ativar o bot, para desativar é só digitar `offbot`, edite seus dados no arquivo `config.js`, sempre que editar os dados, reinicie o bot, basta digitar `onbot`, o bot não tem autostart, então toda vez que sua vps desligar você terá que ativar manualmente com o comando `onbot`

### • 📌Obs
- Use na mesma vps do SSH


### 📝Complemento
- Como instalar e configurar:
https://youtu.be/0SiM7FX76xg?si=fAPo6nTQDWnBRBBK

- Como obter o token do mercado pago:
https://youtu.be/nA4gP6NcF_o?si=f0jfeelvjpJ87FXS

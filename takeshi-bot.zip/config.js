config = {
  dono:"5521993997287", //seu número com 55+ddd
  tempo_teste:"2", //tempo do teste em horas
  valorLogin: 20, //valor do login SSH
  nomeLoja:"Alfa Internet", //nome da sua loja virtual
  linkApp:"https://www.dropbox.com/scl/fi/qpxbuqshhv0ppt9vl7l6j/Alfa-Internet-_4.2.5.apk?rlkey=vr2kfspsqmuv7u2638ev5wg09&st=rj0b8wpg&dl=1", //Link do seu app
  token_mp:"APP_USR-153110256233483-042622-5e61d8c4f515a3e4858a188558b7b725-1697276618" //seu token do mercado pago
}
module.exports = {
  config
}
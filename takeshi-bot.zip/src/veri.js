const axios = require("axios");
const fs = require("fs-extra");
const {
  gerar,
  verificar,
  cancelar
} = require("/etc/takeshi-bot/src/gerar");
const {
  delay
} = require("@whiskeysockets/baileys");
path = {
  p: "/etc/takeshi-bot/data/pedidos.json",
  t: "/etc/takeshi-bot/data/testes.json",
  pa: "/etc/takeshi-bot/data/pagos.json",
  bv: "/etc/takeshi-bot/data/bv.json"
};
async function checkStatus() {
  try {
    pedidos = await JSON.parse(fs.readFileSync(path.p));
    for (var _0x45a603 = 0; _0x45a603 < pedidos.length; _0x45a603++) {
      pedidos = await JSON.parse(fs.readFileSync(path.p));
      status = await verificar(pedidos[_0x45a603].id);
      if (status.status == "approved") {
        console.log("Enviando login id " + status.id);
        env = await axios("http://localhost:7000/pago?user=" + pedidos[_0x45a603].user + "&id=" + pedidos[_0x45a603].id);
        console.log(env.data);
        if (env.data.msg == "sucess") {
          pedidos.splice(_0x45a603, 1);
          await fs.writeFileSync(path.p, JSON.stringify(pedidos));
        } else {
          console.log("Erro ao enviar id " + status.id);
        }
      }
      if (pedidos.length > 0 && Date.now() > pedidos[_0x45a603].expira || status.status == "cancelled") {
        console.log("Expirou, removendo id: " + status.id);
        pedidos.splice(_0x45a603, 1);
        await fs.writeFileSync(path.p, JSON.stringify(pedidos));
        console.log("Removido com sucesso! " + status.id);
      }
      await delay(500);
    }
    await delay(10000);
    checkStatus();
    console.log("Verificando pagamentos...");
  } catch (_0x42d50f) {
    console.log(_0x42d50f);
  }
}
async function baka() {
  await delay(10000);
  console.log("Iniciando verificação de pagamentos...");
  checkStatus();
}
baka();
const _0x20c252 = {
  checkStatus: checkStatus
};
module.exports = _0x20c252;
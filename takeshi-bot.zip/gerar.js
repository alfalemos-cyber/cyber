const axios = require("axios");
const fs = require("fs-extra");
const ms = require("ms");
const {
  config
} = require("/root/config");
const moment = require("moment-timezone");
token = "" + config.token_mp;
hoje = moment.tz("America/Sao_Paulo").format("DD/MM/yyyy");
horario = moment.tz("America/Sao_Paulo").format("HH:mm");
console.log("Ativando em " + hoje + " ás " + horario + " (Brasília)");
expira = ms("10m");
path = {
  p: "/etc/takeshi-bot/data/pedidos.json",
  t: "/etc/takeshi-bot/data/testes.json",
  pa: "/etc/takeshi-bot/data/pagos.json",
  bv: "/etc/takeshi-bot/data/bv.json"
};
function delay(_0x36f7fb) {
  return new Promise(_0x132676 => setTimeout(_0x132676, _0x36f7fb * 1000));
}
async function gerar(_0x32552c, _0x55c5e4) {
  m10 = moment.tz("America/Sao_Paulo").add(10, "m").format("yyyy-MM-DDTHH:mm:ss.000z:00");
  m102 = moment.tz("America/Sao_Paulo").add(10, "m").format("HH:mm");
  requestP = await axios({
    method: "POST",
    url: "https://api.mercadopago.com/v1/payments",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token
    },
    data: {
      transaction_amount: config.valorLogin,
      date_of_expiration: m10,
      description: "Login SSH",
      payment_method_id: "pix",
      payer: {
        email: "desgosto01@gmail.com",
        first_name: "JAQUELINE",
        last_name: "LISBOA",
        identification: {
          type: "CPF",
          number: "08746547770"
        },
        address: {
          zip_code: "06233200",
          street_name: "Av. das Nações Unidas",
          street_number: "3003",
          neighborhood: "Bonfim",
          city: "Osasco",
          federal_unit: "SP"
        }
      }
    }
  });
  resul = requestP.data;
  obj = {
    id: resul.id,
    user: _0x32552c,
    msgkey: _0x55c5e4,
    status: resul.status,
    valor: resul.transaction_amount,
    qrcode: resul.point_of_interaction.transaction_data.qr_code,
    link: resul.point_of_interaction.transaction_data.ticket_url,
    hora: m102,
    expira: Date.now() + expira
  };
  pedidos = await JSON.parse(fs.readFileSync(path.p));
  pedidos.push(obj);
  await fs.writeFileSync(path.p, JSON.stringify(pedidos));
  return obj;
}
async function verificar(_0x46f832) {
  const _0x3924a4 = {
    Authorization: "Bearer " + token
  };
  dados = await axios({
    method: "GET",
    url: "https://api.mercadopago.com/v1/payments/" + _0x46f832,
    headers: _0x3924a4
  });
  resul = dados.data;
  const _0x5ec54e = {
    id: resul.id,
    status: resul.status
  };
  obj = _0x5ec54e;
  return obj;
}
async function cancelar(_0x396ed8) {
  const _0x4e4a74 = {
    Authorization: "Bearer " + token
  };
  dados = await axios({
    method: "PUT",
    url: "https://api.mercadopago.com/v1/payments/" + _0x396ed8,
    data: {
      status: "cancelled"
    },
    headers: _0x4e4a74
  });
  resul = dados.data;
  const _0x385cd8 = {
    id: resul.id,
    status: resul.status
  };
  obj = _0x385cd8;
  return obj;
}
const _0x1f7e39 = {
  delay: delay,
  gerar: gerar,
  verificar: verificar,
  cancelar: cancelar
};
module.exports = _0x1f7e39;
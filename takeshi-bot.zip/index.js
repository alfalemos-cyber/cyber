const { connect } = require("./src/connection");
const { load } = require("./src/loader");
const { badMacHandler } = require("./src/utils/badMacHandler");
const {
  successLog,
  errorLog,
  warningLog,
  bannerLog,
  infoLog,
} = require("./src/utils/logger");

process.on("uncaughtException", (error) => {
  if (badMacHandler.handleError(error, "uncaughtException")) {
    return;
  }

  errorLog(`Erro crítico não capturado: ${error.message}`);
  errorLog(error.stack);

  if (
    !error.message.includes("ENOTFOUND") &&
    !error.message.includes("timeout")
  ) {
    process.exit(1);
  }
});

process.on("unhandledRejection", (reason, promise) => {
  if (badMacHandler.handleError(reason, "unhandledRejection")) {
    return;
  }

  errorLog(`Promessa rejeitada não tratada:`, reason);
});

async function startBot() {
  try {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    process.setMaxListeners(1500);

    bannerLog();
    infoLog("Iniciando meus componentes internos...");

    const stats = badMacHandler.getStats();
    if (stats.errorCount > 0) {
      warningLog(
        `BadMacHandler stats: ${stats.errorCount}/${stats.maxRetries} erros`
      );
    }

    const socket = await connect();

    load(socket);

    successLog("✅ Bot iniciado com sucesso!");

    setInterval(() => {
      const currentStats = badMacHandler.getStats();
      if (currentStats.errorCount > 0) {
        warningLog(
          `BadMacHandler stats: ${currentStats.errorCount}/${currentStats.maxRetries} erros`
        );
      }
    }, 300_000);
  } catch (error) {
    if (badMacHandler.handleError(error, "bot-startup")) {
      warningLog("Erro Bad MAC durante inicialização, tentando novamente...");

      setTimeout(() => {
        startBot();
      }, 5000);
      return;
    }

    errorLog(`Erro ao iniciar o bot: ${error.message}`);
    errorLog(error.stack);
    process.exit(1);
  }
}

startBot();

const {
  default: makeWASocket,
  delay,
  DisconnectReason,
  BufferJSON,
  useMultiFileAuthState
} = require("@whiskeysockets/baileys");
const {
  Boom
} = require("@hapi/boom");
const P = require("pino");
const {
  exec
} = require("child_process");
const express = require("express");
const {
  gerar
} = require("/etc/takeshi-bot/src/gerar");
const app = express();
const moment = require("moment-timezone");
const fs = require("fs-extra");
const ms = require("ms");
const pms = require("parse-ms");
const {
  config
} = require("/root/config");
time = ms("1d");
time2 = ms("40m");
expiraZ = ms("31d");
d31 = moment.tz("America/Sao_Paulo").add(31, "d").format("DD/MM/yyyy");
app.listen(7000);
dono = [config.dono + "@s.whatsapp.net"];
dono2 = "" + config.dono;
path = {
  p: "/etc/takeshi-bot/data/pedidos.json",
  t: "/etc/takeshi-bot/data/testes.json",
  pa: "/etc/takeshi-bot/data/pagos.json",
  bv: "/etc/takeshi-bot/data/bv.json"
};
async function checkUser(_0x531a2c) {
  pedidos = await JSON.parse(fs.readFileSync(path.p));
  for (var _0x23c5fd = 0; _0x23c5fd < pedidos.length; _0x23c5fd++) {
    if (pedidos[_0x23c5fd].user == _0x531a2c) {
      return true;
    }
  }
  return false;
}
async function checkTeste(_0x2ddd9f) {
  testes = await JSON.parse(fs.readFileSync(path.t));
  testes = await JSON.parse(fs.readFileSync(path.t));
  for (var _0x5d0312 = 0; _0x5d0312 < testes.length; _0x5d0312++) {
    if (testes[_0x5d0312].user == _0x2ddd9f) {
      if (Date.now() < testes[_0x5d0312].expira) {
        return true;
      }
      if (Date.now() > testes[_0x5d0312].expira) {
        testes.splice(_0x5d0312, 1);
        await fs.writeFileSync(path.t, JSON.stringify(testes));
        return false;
      }
    }
  }
  return false;
}
async function checkBv(_0x1fbe55) {
  bvtime = await JSON.parse(fs.readFileSync(path.bv));
  for (var _0xdf0669 = 0; _0xdf0669 < bvtime.length; _0xdf0669++) {
    if (bvtime[_0xdf0669].user == _0x1fbe55) {
      if (Date.now() < bvtime[_0xdf0669].expira) {
        return true;
      }
      if (Date.now() > bvtime[_0xdf0669].expira) {
        bvtime.splice(_0xdf0669, 1);
        await fs.writeFileSync(path.bv, JSON.stringify(bvtime));
        return false;
      }
    }
  }
  return false;
}
async function gravarBv(_0x5c3a60) {
  bvtime = await JSON.parse(fs.readFileSync(path.bv));
  obj = {
    user: _0x5c3a60,
    expira: Date.now() + time2
  };
  bvtime.push(obj);
  await fs.writeFileSync(path.bv, JSON.stringify(bvtime));
}
async function gravarTeste(_0x467a46) {
  testes = await JSON.parse(fs.readFileSync(path.t));
  obj = {
    user: _0x467a46,
    expira: Date.now() + time
  };
  testes.push(obj);
  await fs.writeFileSync(path.t, JSON.stringify(testes));
}
function ale() {
  i = 10000000000000000000;
  return Math.floor(Math.random() * (i + 1));
}
function repla(_0x2d7f1c) {
  i = _0x2d7f1c.indexOf("@");
  return _0x2d7f1c.slice(0, i);
}
async function chackPago(_0x48ceaa) {
  pagos = await JSON.parse(fs.readFileSync(path.pa));
  for (var _0x3628cb = 0; _0x3628cb < pagos.length; _0x3628cb++) {
    if (pagos[_0x3628cb].user == _0x48ceaa) {
      return true;
    }
  }
  return false;
}
async function checkLogins(_0x3de5b5) {
  pagos = await JSON.parse(fs.readFileSync(path.pa));
  for (var _0x4639dc = 0; _0x4639dc < pagos.length; _0x4639dc++) {
    if (pagos[_0x4639dc].user == _0x3de5b5) {
      logins = pagos[_0x4639dc].logins;
      quanti = logins.length;
      tesk = "Você tem *" + quanti + "* login's Premium";
      for (var _0x4639dc = 0; _0x4639dc < logins.length; _0x4639dc++) {
        usu = logins[_0x4639dc].usuario;
        sen = logins[_0x4639dc].senha;
        limi = logins[_0x4639dc].limite;
        vali = logins[_0x4639dc].Validade;
        exp = pms(logins[_0x4639dc].expira - Date.now());
        exp = exp.days + " dias";
        exps = logins[_0x4639dc].expira;
        if (Date.now() > exp) {
          exp = "venceu";
        }
        tesk = tesk + ("\n\n*👤Usuário:* " + usu + "\n*🔐Senha:* " + sen + "\n*📲Limite:* " + limi + "\n*⌛Validade:* " + vali + " (" + exp + ")\n\n===============");
      }
      return tesk;
    }
  }
  return "Você não tem logins Premium";
}
async function connectToWhatsApp() {
  const {
    state: _0x18c815,
    saveCreds: _0x2b538c
  } = await useMultiFileAuthState("/etc/takeshi-bot/login");
  const _0xa7e71e = await makeWASocket({
    logger: P({
      level: "silent"
    }),
    printQRInTerminal: true,
    auth: _0x18c815,
    keepAliveIntervalMs: 16000
  });
  _0xa7e71e.ev.on("creds.update", _0x2b538c);
  _0xa7e71e.ev.on("connection.update", async _0x2d142b => {
    const {
      connection: _0xce04a4,
      lastDisconnect: _0x2b3182
    } = _0x2d142b;
    if (_0xce04a4 == "connecting") {
      console.log("Conectando...");
    }
    if (_0xce04a4 === "close") {
      console.log(DisconnectReason);
      console.log("Conexão fechada por: ", _0x2b3182, ", Reconectando...");
      await delay(3000);
      connectToWhatsApp();
    } else if (_0xce04a4 === "open") {
      console.log("CONECTADO COM SUCESSO!");
      console.log("#######################");
      console.log("Caso você tenha lido o qrcode agora, espere 10 segundos e depois dê um CTRL+c");
      console.log("#######################");
    }
  });
  console.log("Abrindo navegador...");
  app.get("/pago", async (_0x43964b, _0x452841) => {
    try {
      var {
        user: _0x2c46fd
      } = _0x43964b.query;
      var {
        id: _0x5a4ce9
      } = _0x43964b.query;
      console.log(_0x2c46fd, _0x5a4ce9);
      if (!_0x2c46fd.includes("@s")) {
        return _0x452841.json({
          msg: "bad request"
        });
      }
      pagtoC = await _0xa7e71e.sendMessage(_0x2c46fd, {
        text: "Pagamento id: " + _0x5a4ce9 + " confirmado!"
      }).catch(_0x1a0a61 => {
        console.log("deu erro");
        console.log(_0x1a0a61);
        _0x452841.json({
          msg: "error"
        });
      });
      usuarioV = "user" + ("" + ale()).slice(0, 4);
      senha = ("" + ale()).slice(0, 4);
      exec("sh /etc/takeshi-bot/src/user.sh " + usuarioV + " " + senha);
      const _0x14bb28 = {
        text: "*•Informações do login•*\n\n*👤Usuário:* " + usuarioV + "\n*🔐Senha:* " + senha + "\n*📲Limite:* 1\n*⌛Validade:* " + d31 + " (31 dias)"
      };
      const _0x1453f3 = {
        quoted: pagtoC
      };
      await _0xa7e71e.sendMessage(_0x2c46fd, _0x14bb28, _0x1453f3).catch(_0x2fb319 => {
        console.log("deu erro");
        console.log(_0x2fb319);
        _0x452841.json({
          msg: "error"
        });
      });
      console.log(_0x2c46fd);
      if (await chackPago(_0x2c46fd)) {
        pagos = await JSON.parse(fs.readFileSync(path.pa));
        obj = {
          usuario: usuarioV,
          senha: senha,
          limite: 1,
          Validade: d31,
          expira: Date.now() + expiraZ
        };
        for (var _0x2f16bf = 0; _0x2f16bf < pagos.length; _0x2f16bf++) {
          if (pagos[_0x2f16bf].user == _0x2c46fd) {
            pagos[_0x2f16bf].logins.push(obj);
            await fs.writeFileSync(path.pa, JSON.stringify(pagos));
          }
        }
      } else {
        pagos = await JSON.parse(fs.readFileSync(path.pa));
        obj = {
          user: _0x2c46fd,
          logins: [{
            usuario: usuarioV,
            senha: senha,
            limite: 1,
            Validade: d31,
            expira: Date.now() + expiraZ
          }]
        };
        pagos.push(obj);
        await fs.writeFileSync(path.pa, JSON.stringify(pagos));
      }
      _0x452841.json({
        msg: "sucess"
      });
    } catch (_0x116338) {
      console.log(_0x116338);
      console.log("deu erro");
    }
  });
  _0xa7e71e.ev.on("messages.upsert", async _0x1c501a => {
    _0xa7e71e.sendPresenceUpdate("available");
    message = _0x1c501a.messages[0];
    msg = message.message;
    if (!msg) {
      return;
    }
    key = message.key;
    fromMe = key.fromMe;
    if (key.remoteJid == "status@broadcast") {
      return;
    }
    if (fromMe) {
      return;
    }
    from = key.remoteJid;
    isGroup = from.includes("@g.us");
    jid = isGroup ? key.participant : from;
    if (isGroup) {
      return;
    }
    console.log("$$$$$$$$$$$$$");
    galo = Object.keys(msg);
    body = galo.includes("conversation") ? msg.conversation : galo.includes("extendedTextMessage") ? msg.extendedTextMessage.text : "midia";
    body = body.toLowerCase();
    async function _0x9be507(_0x39fe43) {
      const _0x3ae202 = {
        text: _0x39fe43
      };
      const _0x20ce93 = {
        quoted: message
      };
      await _0xa7e71e.sendMessage(from, _0x3ae202, _0x20ce93);
    }
    async function _0x2ab892(_0x1a76ad, _0x3f1e32) {
      const _0x478538 = {
        text: _0x3f1e32
      };
      await _0xa7e71e.sendMessage(_0x1a76ad, _0x478538);
    }
    if (!isGroup) {
      console.log("\n\nMensagem no privado de " + repla(jid) + "\n\nMensagem: " + body + "\n\n############");
    }
    _0xa7e71e.sendPresenceUpdate("available", jid);
    _0xa7e71e.readMessages([key]);
    if (isGroup) {
      return;
    }
    switch (body) {
      case "1":
      case "01":
        if (await checkTeste(jid)) {
          return _0x9be507("Você já gerou um teste hoje, só poderá gerar outro em 24h");
        }
        usuarioT = "teste" + ("" + ale()).slice(0, 4);
        exec("sh /etc/takeshi-bot/src/teste.sh " + usuarioT + " " + config.tempo_teste * 60);
        const _0x268546 = {
          text: "*•Informações do login•*\n\n*👤Usuário:* " + usuarioT + "\n*🔐Senha:* 1234\n*📲Limite:* 1\n*⌛Validade:* " + config.tempo_teste + "h"
        };
        const _0x3fc20b = {
          quoted: message
        };
        tesy = await _0xa7e71e.sendMessage(jid, _0x268546, _0x3fc20b);
        const _0x2b391e = {
          quoted: tesy
        };
        await _0xa7e71e.sendMessage(jid, {
          text: "Aproveite bem seu teste 🔥"
        }, _0x2b391e);
        await delay(500);
        gravarTeste(jid);
        break;
      case "2":
      case "02":
        placa2 = "*•Informações do produto•*\n\n*🏷️Valor:* R$" + config.valorLogin + "\n*📲Limite:* 1\n*⌛Validade:* 30 dias\n\n📌Sempre faça um teste antes de comprar!\nPara obter o app, digite o comando abaixo ⤵️\n\n/app\n\nDeseja comprar? *Sim* ou *Não*";
        _0x9be507(placa2);
        break;
      case "sim":
      case "si":
      case "ss":
      case "s":
        if (await checkUser(jid)) {
          return _0x9be507("Você tem um pedido em andamento, pague ou espere ele expirar para fazer outro pedido");
        }
        _0x9be507("Gerando Qrcode...");
        dados = await gerar(jid, message);
        placa = "*Informações do Qrcode:*\n\n🆔Id: " + dados.id + "\n🏷️Valor: R$" + dados.valor + "\n⌛Expira em: 10 min\nàs *" + dados.hora + "* _(horário de Brasília)_\n\n📌Seu login será enviado assim que seu pagamento for identificado, pode demorar cerca de 1 minuto.\n\n_Qrcode copia e cola logo abaixo_ ⤵️";
        const _0x492626 = {
          text: placa
        };
        mcode = await _0xa7e71e.sendMessage(dados.user, _0x492626, {
          quoted: dados.msgkey
        });
        const _0x4306df = {
          quoted: mcode
        };
        await _0xa7e71e.sendMessage(dados.user, {
          text: dados.qrcode
        }, _0x4306df);
        break;
      case "nao":
      case "não":
      case "no":
      case "n":
      case "nn":
        _0x9be507("Tudo certo! Se precisar é só me chamar! 😉");
        break;
      case "5":
      case "05":
        const _0x3a2ccc = {
          text: "*☎️Suporte*\n\n🆔@" + dono2,
          mentions: dono
        };
        const _0x237052 = {
          quoted: message
        };
        await _0xa7e71e.sendMessage(jid, _0x3a2ccc, _0x237052);
        break;
      case "3":
      case "03":
        gama = await checkLogins(jid);
        const _0x344d23 = {
          text: gama
        };
        const _0x50c8de = {
          quoted: message
        };
        await _0xa7e71e.sendMessage(jid, _0x344d23, _0x50c8de);
        break;
      case "/app":
      case "app":
      case "4":
      case "04":
        _0x9be507("Aguarde...");
        const _0x464e4c = {
          text: "Faça o download do app através do link abaixo⤵️\n\n" + config.linkApp + "\n\n📌Caso o link não esteja clicável, salve meu contato que ele ficará"
        };
        const _0x59ebed = {
          quoted: message
        };
        await _0xa7e71e.sendMessage(jid, _0x464e4c, _0x59ebed);
        break;
      case "/menu":
      case "menu":
        boasvindas = "Seja Bem vindo(a) a *" + config.nomeLoja + "!* Fique a vontade para escolher alguma das opções abaixo:\n\n*[01]* Gerar teste ⌛\n*[02]* Comprar login 30 dias 📆\n*[03]* Verificar Logins 🔍\n*[04]* Aplicativo 📱\n*[05]* Suporte 👤";
        _0x9be507(boasvindas);
        break;
      default:
        if (await checkBv(jid)) {
          return;
        }
        boasvindas = "Seja Bem vindo(a) a *" + config.nomeLoja + "!* Fique a vontade para escolher alguma das opções abaixo:\n\n*[01]* Gerar teste ⌛\n*[02]* Comprar login 30 dias 📆\n*[03]* Verificar Logins 🔍\n*[04]* Aplicativo 📱\n*[05]* Suporte 👤";
        const _0x712e4a = {
          text: boasvindas
        };
        const _0x287d14 = {
          quoted: message
        };
        tagbv = await _0xa7e71e.sendMessage(jid, _0x712e4a, _0x287d14);
        const _0x4e7c59 = {
          quoted: tagbv
        };
        await _0xa7e71e.sendMessage(jid, {
          text: "Para ver está mensagem novamente, digite:\n\n*/menu*"
        }, _0x4e7c59);
        await delay(500);
        gravarBv(jid);
    }
  });
}
connectToWhatsApp();
const {
  checkStatus
} = require("/etc/takeshi-bot/src/veri");
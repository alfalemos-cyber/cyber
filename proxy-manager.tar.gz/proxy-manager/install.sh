#!/bin/bash

# Script de Instalação do Proxy Manager
# Desenvolvido para Ubuntu/Debian
# Version: 1.0

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_message() {
    echo -e "${2}${1}${NC}"
}

# Função para imprimir cabeçalho
print_header() {
    clear
    print_message "╔══════════════════════════════════════════════════════════════╗" $CYAN
    print_message "║                    PROXY MANAGER v1.0                       ║" $CYAN
    print_message "║                  Script de Instalação                       ║" $CYAN
    print_message "║                    Ubuntu/Debian                             ║" $CYAN
    print_message "╚══════════════════════════════════════════════════════════════╝" $CYAN
    echo ""
}

# Função para verificar se está executando como root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_message "Este script deve ser executado como root (sudo)" $RED
        exit 1
    fi
}

# Função para detectar o sistema operacional
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    else
        print_message "Não foi possível detectar o sistema operacional" $RED
        exit 1
    fi
    
    case $OS in
        "Ubuntu"*)
            print_message "Sistema detectado: $OS $VER" $GREEN
            PACKAGE_MANAGER="apt-get"
            ;;
        "Debian"*)
            print_message "Sistema detectado: $OS $VER" $GREEN
            PACKAGE_MANAGER="apt-get"
            ;;
        *)
            print_message "Sistema operacional não suportado: $OS" $RED
            print_message "Este script é compatível apenas com Ubuntu e Debian" $YELLOW
            exit 1
            ;;
    esac
}

# Função para atualizar repositórios
update_repositories() {
    print_message "Atualizando repositórios..." $YELLOW
    $PACKAGE_MANAGER update -qq
    if [[ $? -eq 0 ]]; then
        print_message "Repositórios atualizados com sucesso" $GREEN
    else
        print_message "Erro ao atualizar repositórios" $RED
        exit 1
    fi
}

# Função para instalar dependências
install_dependencies() {
    print_message "Instalando dependências..." $YELLOW
    
    DEPENDENCIES="python3 python3-pip screen lsof net-tools wget curl tar gzip"
    
    for dep in $DEPENDENCIES; do
        print_message "Instalando $dep..." $BLUE
        $PACKAGE_MANAGER install -y $dep -qq
        if [[ $? -eq 0 ]]; then
            print_message "$dep instalado com sucesso" $GREEN
        else
            print_message "Erro ao instalar $dep" $RED
            exit 1
        fi
    done
    
    print_message "Todas as dependências foram instaladas" $GREEN
}

# Função para criar estrutura de diretórios
create_directories() {
    print_message "Criando estrutura de diretórios..." $YELLOW
    
    DIRECTORIES=(
        "/etc/proxy-manager"
        "/etc/proxy-manager/backups"
        "/var/log"
        "/usr/local/bin"
    )
    
    for dir in "${DIRECTORIES[@]}"; do
        if [[ ! -d $dir ]]; then
            mkdir -p $dir
            print_message "Diretório criado: $dir" $GREEN
        else
            print_message "Diretório já existe: $dir" $BLUE
        fi
    done
}

# Função para copiar arquivos
copy_files() {
    print_message "Copiando arquivos do sistema..." $YELLOW
    
    # Copiar arquivo principal
    if [[ -f "main.py" ]]; then
        cp main.py /usr/local/bin/proxy-manager
        chmod +x /usr/local/bin/proxy-manager
        print_message "Arquivo principal copiado para /usr/local/bin/proxy-manager" $GREEN
    else
        print_message "Arquivo main.py não encontrado!" $RED
        exit 1
    fi
    
    # Copiar script de serviço systemd se existir
    if [[ -f "proxy-manager.service" ]]; then
        cp proxy-manager.service /etc/systemd/system/
        print_message "Serviço systemd copiado" $GREEN
    fi
    
    # Copiar script de uninstall se existir
    if [[ -f "uninstall.sh" ]]; then
        cp uninstall.sh /etc/proxy-manager/
        chmod +x /etc/proxy-manager/uninstall.sh
        print_message "Script de desinstalação copiado" $GREEN
    fi
}

# Função para baixar script do proxy
download_proxy_script() {
    print_message "Baixando script do proxy..." $YELLOW
    
    cd /etc/proxy-manager/
    wget -q https://github.com/alfalemos-cyber/cyber/raw/main/proxydt

    if [[ $? -eq 0 ]]; then
        chmod 777 proxydt
        print_message "Script do proxy baixado com sucesso" $GREEN
    else
        print_message "Aviso: Não foi possível baixar o script do proxy" $YELLOW
        print_message "Você pode baixá-lo manualmente depois usando o menu do programa" $BLUE
    fi
}

# Função para criar configurações padrão
create_default_configs() {
    print_message "Criando configurações padrão..." $YELLOW
    
    # Configuração principal
    cat > /etc/proxy-manager/config.json << EOF
{
  "default_port": 80,
  "default_response": "ALFA-PROXY",
  "auto_start": false,
  "log_enabled": true
}
EOF
    
    # Configuração de serviços
    cat > /etc/proxy-manager/services.json << EOF
{
  "proxy": {
    "name": "Proxy HTTP",
    "active": false,
    "port": 80,
    "response": "ALFA-PROXY",
    "process_name": "proxydt"
  },
  "websocket": {
    "name": "WebSocket",
    "active": false,
    "port": 8080,
    "response": "WS-PROXY",
    "process_name": "proxydt"
  },
  "websocket_secure": {
    "name": "WebSocket Security",
    "active": false,
    "port": 443,
    "response": "WSS-PROXY",
    "process_name": "proxydt"
  }
}
EOF
    
    print_message "Configurações padrão criadas" $GREEN
}

# Função para criar comando global
create_global_command() {
    print_message "Criando comando global..." $YELLOW
    
    # Criar link simbólico
    if [[ -L /usr/bin/proxy-manager ]]; then
        rm /usr/bin/proxy-manager
    fi
    
    ln -s /usr/local/bin/proxy-manager /usr/bin/proxy-manager
    
    print_message "Comando global 'proxy-manager' criado" $GREEN
    print_message "Agora você pode executar o programa digitando: proxy-manager" $BLUE
}

# Função para configurar systemd service (opcional)
setup_systemd_service() {
    if [[ -f "/etc/systemd/system/proxy-manager.service" ]]; then
        print_message "Configurando serviço systemd..." $YELLOW
        
        systemctl daemon-reload
        systemctl enable proxy-manager.service
        
        print_message "Serviço systemd configurado" $GREEN
        print_message "Para iniciar automaticamente: systemctl start proxy-manager" $BLUE
    fi
}

# Função para verificar instalação
verify_installation() {
    print_message "Verificando instalação..." $YELLOW
    
    # Verificar se o arquivo principal existe
    if [[ -f "/usr/local/bin/proxy-manager" ]]; then
        print_message "Arquivo principal: OK" $GREEN
    else
        print_message "Arquivo principal: ERRO" $RED
        return 1
    fi
    
    # Verificar se o comando global funciona
    if command -v proxy-manager &> /dev/null; then
        print_message "Comando global: OK" $GREEN
    else
        print_message "Comando global: ERRO" $RED
        return 1
    fi
    
    # Verificar dependências
    DEPS_CHECK="python3 screen lsof netstat wget"
    for cmd in $DEPS_CHECK; do
        if command -v $cmd &> /dev/null; then
            print_message "Dependência $cmd: OK" $GREEN
        else
            print_message "Dependência $cmd: ERRO" $RED
            return 1
        fi
    done
    
    return 0
}

# Função para mostrar informações pós-instalação
show_post_install_info() {
    print_message "╔══════════════════════════════════════════════════════════════╗" $GREEN
    print_message "║                     INSTALAÇÃO CONCLUÍDA                    ║" $GREEN
    print_message "╚══════════════════════════════════════════════════════════════╝" $GREEN
    echo ""
    
    print_message "Como usar o Proxy Manager:" $WHITE
    echo ""
    print_message "1. Execute o programa:" $YELLOW
    print_message "   proxy-manager" $CYAN
    echo ""
    print_message "2. Ou execute diretamente:" $YELLOW
    print_message "   sudo /usr/local/bin/proxy-manager" $CYAN
    echo ""
    
    print_message "Arquivos instalados:" $WHITE
    print_message "• Programa principal: /usr/local/bin/proxy-manager" $BLUE
    print_message "• Configurações: /etc/proxy-manager/" $BLUE
    print_message "• Logs: /var/log/proxy-manager.log" $BLUE
    echo ""
    
    print_message "Para desinstalar:" $WHITE
    print_message "   sudo /etc/proxy-manager/uninstall.sh" $CYAN
    echo ""
    
    print_message "Recursos disponíveis:" $WHITE
    print_message "• Gerenciamento de serviços proxy" $GREEN
    print_message "• Menu interativo completo" $GREEN
    print_message "• Monitoramento de portas" $GREEN
    print_message "• Sistema de logs" $GREEN
    print_message "• Backup/Restore de configurações" $GREEN
    echo ""
    
    print_message "IMPORTANTE: Execute sempre como root (sudo)" $RED
    echo ""
}

# Função principal
main() {
    print_header
    
    print_message "Iniciando instalação do Proxy Manager..." $WHITE
    echo ""
    
    # Verificações iniciais
    check_root
    detect_os
    
    # Processo de instalação
    update_repositories
    install_dependencies
    create_directories
    copy_files
    download_proxy_script
    create_default_configs
    create_global_command
    setup_systemd_service
    
    # Verificação final
    if verify_installation; then
        show_post_install_info
    else
        print_message "Erro na verificação da instalação!" $RED
        exit 1
    fi
    
    print_message "Instalação concluída com sucesso!" $GREEN
    print_message "Execute 'proxy-manager' para começar" $CYAN
}

# Tratamento de sinais
trap 'print_message "\nInstalação interrompida pelo usuário" $YELLOW; exit 1' INT TERM

# Executar função principal
main "$@"
#!/bin/bash

# Script de Desinstalação do Proxy Manager
# Desenvolvido para Ubuntu/Debian
# Version: 1.0

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_message() {
    echo -e "${2}${1}${NC}"
}

# Função para imprimir cabeçalho
print_header() {
    clear
    print_message "╔══════════════════════════════════════════════════════════════╗" $RED
    print_message "║                    PROXY MANAGER v1.0                       ║" $RED
    print_message "║                 Script de Desinstalação                     ║" $RED
    print_message "║                    Ubuntu/Debian                             ║" $RED
    print_message "╚══════════════════════════════════════════════════════════════╝" $RED
    echo ""
}

# Função para verificar se está executando como root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_message "Este script deve ser executado como root (sudo)" $RED
        exit 1
    fi
}

# Função para parar todos os serviços
stop_all_services() {
    print_message "Parando todos os serviços do Proxy Manager..." $YELLOW
    
    # Parar serviços conhecidos nas portas padrão
    PORTS=(80 8080 443 8000 8888 9090)
    
    for port in "${PORTS[@]}"; do
        if lsof -i:$port &> /dev/null; then
            print_message "Parando serviços na porta $port..." $BLUE
            kill -9 $(lsof -t -i:$port) 2>/dev/null
            if [[ $? -eq 0 ]]; then
                print_message "Serviços na porta $port parados" $GREEN
            fi
        fi
    done
    
    # Parar sessões screen do proxy manager
    screen -list | grep -E "(proxydt|proxy|websocket)" | cut -d. -f1 | awk '{print $1}' | while read session; do
        if [[ ! -z "$session" ]]; then
            print_message "Parando sessão screen: $session" $BLUE
            screen -S "$session" -X quit 2>/dev/null
        fi
    done
    
    print_message "Todos os serviços foram parados" $GREEN
}

# Função para parar e desabilitar serviço systemd
stop_systemd_service() {
    if systemctl is-active --quiet proxy-manager; then
        print_message "Parando serviço systemd..." $YELLOW
        systemctl stop proxy-manager
        print_message "Serviço systemd parado" $GREEN
    fi
    
    if systemctl is-enabled --quiet proxy-manager; then
        print_message "Desabilitando serviço systemd..." $YELLOW
        systemctl disable proxy-manager
        print_message "Serviço systemd desabilitado" $GREEN
    fi
}

# Função para remover arquivos do sistema
remove_files() {
    print_message "Removendo arquivos do sistema..." $YELLOW
    
    # Lista de arquivos e diretórios para remover
    FILES_TO_REMOVE=(
        "/usr/local/bin/proxy-manager"
        "/usr/bin/proxy-manager"
        "/etc/systemd/system/proxy-manager.service"
    )
    
    DIRS_TO_REMOVE=(
        "/etc/proxy-manager"
    )
    
    # Remover arquivos
    for file in "${FILES_TO_REMOVE[@]}"; do
        if [[ -f "$file" ]] || [[ -L "$file" ]]; then
            rm -f "$file"
            print_message "Removido: $file" $GREEN
        fi
    done
    
    # Remover diretórios (com confirmação para logs)
    for dir in "${DIRS_TO_REMOVE[@]}"; do
        if [[ -d "$dir" ]]; then
            if [[ "$dir" == "/etc/proxy-manager" ]]; then
                # Perguntar sobre logs e configurações
                echo ""
                print_message "Encontrado diretório de configurações: $dir" $YELLOW
                print_message "Este diretório contém:" $BLUE
                
                if [[ -f "$dir/config.json" ]]; then
                    print_message "• Configurações do sistema" $BLUE
                fi
                
                if [[ -f "$dir/services.json" ]]; then
                    print_message "• Configurações de serviços" $BLUE
                fi
                
                if [[ -d "$dir/backups" ]]; then
                    backup_count=$(ls -1 "$dir/backups" 2>/dev/null | wc -l)
                    if [[ $backup_count -gt 0 ]]; then
                        print_message "• $backup_count arquivo(s) de backup" $BLUE
                    fi
                fi
                
                echo ""
                read -p "Deseja remover todas as configurações e backups? [s/N]: " remove_configs
                
                if [[ "$remove_configs" =~ ^[Ss]$ ]]; then
                    rm -rf "$dir"
                    print_message "Removido: $dir (com todas as configurações)" $GREEN
                else
                    print_message "Configurações mantidas em: $dir" $YELLOW
                    print_message "Você pode removê-las manualmente depois se desejar" $BLUE
                fi
            else
                rm -rf "$dir"
                print_message "Removido: $dir" $GREEN
            fi
        fi
    done
}

# Função para limpar logs
clean_logs() {
    LOG_FILE="/var/log/proxy-manager.log"
    
    if [[ -f "$LOG_FILE" ]]; then
        echo ""
        read -p "Deseja remover o arquivo de log ($LOG_FILE)? [s/N]: " remove_log
        
        if [[ "$remove_log" =~ ^[Ss]$ ]]; then
            rm -f "$LOG_FILE"
            print_message "Log removido: $LOG_FILE" $GREEN
        else
            print_message "Log mantido: $LOG_FILE" $YELLOW
        fi
    fi
}

# Função para recarregar systemd
reload_systemd() {
    print_message "Recarregando configuração do systemd..." $YELLOW
    systemctl daemon-reload
    print_message "Systemd recarregado" $GREEN
}

# Função para verificar desinstalação
verify_uninstall() {
    print_message "Verificando desinstalação..." $YELLOW
    
    ERRORS=0
    
    # Verificar arquivos removidos
    if [[ -f "/usr/local/bin/proxy-manager" ]]; then
        print_message "ERRO: Arquivo principal ainda existe" $RED
        ERRORS=$((ERRORS + 1))
    else
        print_message "Arquivo principal: Removido" $GREEN
    fi
    
    # Verificar comando global
    if command -v proxy-manager &> /dev/null; then
        print_message "ERRO: Comando global ainda existe" $RED
        ERRORS=$((ERRORS + 1))
    else
        print_message "Comando global: Removido" $GREEN
    fi
    
    # Verificar serviço systemd
    if [[ -f "/etc/systemd/system/proxy-manager.service" ]]; then
        print_message "ERRO: Serviço systemd ainda existe" $RED
        ERRORS=$((ERRORS + 1))
    else
        print_message "Serviço systemd: Removido" $GREEN
    fi
    
    # Verificar processos ativos
    if pgrep -f "proxy-manager\|proxydt" &> /dev/null; then
        print_message "AVISO: Ainda existem processos relacionados rodando" $YELLOW
        print_message "Execute: sudo pkill -f 'proxy-manager|proxydt'" $BLUE
    else
        print_message "Processos: Nenhum encontrado" $GREEN
    fi
    
    return $ERRORS
}

# Função para mostrar informações pós-desinstalação
show_post_uninstall_info() {
    print_message "╔══════════════════════════════════════════════════════════════╗" $GREEN
    print_message "║                   DESINSTALAÇÃO CONCLUÍDA                   ║" $GREEN
    print_message "╚══════════════════════════════════════════════════════════════╝" $GREEN
    echo ""
    
    print_message "O Proxy Manager foi removido do sistema" $WHITE
    echo ""
    
    if [[ -d "/etc/proxy-manager" ]]; then
        print_message "Configurações mantidas em:" $YELLOW
        print_message "• /etc/proxy-manager/" $BLUE
        print_message "  Para remover completamente: sudo rm -rf /etc/proxy-manager/" $CYAN
        echo ""
    fi
    
    if [[ -f "/var/log/proxy-manager.log" ]]; then
        print_message "Log mantido em:" $YELLOW
        print_message "• /var/log/proxy-manager.log" $BLUE
        print_message "  Para remover: sudo rm /var/log/proxy-manager.log" $CYAN
        echo ""
    fi
    
    print_message "As dependências instaladas (python3, screen, lsof, etc.)" $BLUE
    print_message "foram mantidas no sistema pois podem ser usadas por outros programas" $BLUE
    echo ""
    
    print_message "Obrigado por usar o Proxy Manager!" $GREEN
}

# Função para confirmação
confirm_uninstall() {
    echo ""
    print_message "ATENÇÃO: Esta ação irá remover completamente o Proxy Manager" $RED
    print_message "e parar todos os serviços relacionados!" $RED
    echo ""
    
    read -p "Tem certeza que deseja continuar? [s/N]: " confirm
    
    if [[ ! "$confirm" =~ ^[Ss]$ ]]; then
        print_message "Desinstalação cancelada pelo usuário" $YELLOW
        exit 0
    fi
    
    echo ""
    print_message "Iniciando desinstalação..." $WHITE
    sleep 2
}

# Função principal
main() {
    print_header
    
    # Verificações iniciais
    check_root
    confirm_uninstall
    
    # Processo de desinstalação
    stop_all_services
    stop_systemd_service
    remove_files
    clean_logs
    reload_systemd
    
    # Verificação final
    if verify_uninstall; then
        show_post_uninstall_info
        print_message "Desinstalação concluída com sucesso!" $GREEN
    else
        print_message "Desinstalação concluída com alguns avisos" $YELLOW
        print_message "Verifique as mensagens acima" $BLUE
    fi
}

# Tratamento de sinais
trap 'print_message "\nDesinstalação interrompida pelo usuário" $YELLOW; exit 1' INT TERM

# Executar função principal
main "$@"
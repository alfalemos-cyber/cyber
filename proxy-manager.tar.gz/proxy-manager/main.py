#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sistema de Gerenciamento de Proxy e Serviços
Desenvolvido para Ubuntu/Debian
Author: AI Assistant
Version: 1.0
"""

import os
import sys
import subprocess
import json
import time
import signal
from typing import Dict, List, Optional, Tuple
import re
from datetime import datetime

class Colors:
    """Classe para cores do terminal"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

class ProxyManager:
    """Classe principal para gerenciamento do sistema de proxy"""
    
    def __init__(self):
        self.config_file = "/etc/proxy-manager/config.json"
        self.proxy_script = "/etc/proxy-manager/proxydt"
        self.services_file = "/etc/proxy-manager/services.json"
        self.log_file = "/var/log/proxy-manager.log"
        
        # Criar diretórios necessários
        self.setup_directories()
        
        # Carregar configurações
        self.config = self.load_config()
        self.services = self.load_services()

    def setup_directories(self):
        """Criar diretórios necessários"""
        directories = [
            "/etc/proxy-manager",
            "/var/log"
        ]
        
        for directory in directories:
            if not os.path.exists(directory):
                try:
                    os.makedirs(directory, exist_ok=True)
                except PermissionError:
                    print(f"{Colors.RED}Erro: Execute como root (sudo){Colors.END}")
                    sys.exit(1)

    def log_message(self, message: str, level: str = "INFO"):
        """Registrar mensagem no log"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] [{level}] {message}\n"
        
        try:
            with open(self.log_file, "a") as f:
                f.write(log_entry)
        except:
            pass

    def load_config(self) -> Dict:
        """Carregar configurações"""
        default_config = {
            "default_port": 80,
            "default_response": "ALFA-PROXY",
            "auto_start": False,
            "log_enabled": True
        }
        
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    # Mesclar com configurações padrão
                    for key, value in default_config.items():
                        if key not in config:
                            config[key] = value
                    return config
            except:
                return default_config
        
        return default_config

    def save_config(self):
        """Salvar configurações"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"{Colors.RED}Erro ao salvar configuração: {e}{Colors.END}")

    def load_services(self) -> Dict:
        """Carregar serviços"""
        default_services = {
            "proxy": {
                "name": "Proxy HTTP",
                "active": False,
                "port": 80,
                "response": "ALFA-PROXY",
                "process_name": "proxydt"
            },
            "websocket": {
                "name": "WebSocket",
                "active": False,
                "port": 8080,
                "response": "WS-PROXY",
                "process_name": "proxydt"
            },
            "websocket_secure": {
                "name": "WebSocket Security",
                "active": False,
                "port": 443,
                "response": "WSS-PROXY",
                "process_name": "proxydt"
            }
        }
        
        if os.path.exists(self.services_file):
            try:
                with open(self.services_file, 'r') as f:
                    services = json.load(f)
                    # Mesclar com serviços padrão
                    for key, value in default_services.items():
                        if key not in services:
                            services[key] = value
                    return services
            except:
                return default_services
        
        return default_services

    def save_services(self):
        """Salvar serviços"""
        try:
            with open(self.services_file, 'w') as f:
                json.dump(self.services, f, indent=2)
        except Exception as e:
            print(f"{Colors.RED}Erro ao salvar serviços: {e}{Colors.END}")

    def run_command(self, command: str, capture_output: bool = True) -> Tuple[bool, str]:
        """Executar comando no sistema"""
        try:
            if capture_output:
                result = subprocess.run(command, shell=True, capture_output=True, text=True)
                return result.returncode == 0, result.stdout.strip()
            else:
                result = subprocess.run(command, shell=True)
                return result.returncode == 0, ""
        except Exception as e:
            return False, str(e)

    def check_port_status(self, port: int) -> bool:
        """Verificar se uma porta está aberta"""
        success, output = self.run_command(f"lsof -i:{port}")
        return success and output

    def get_open_ports(self) -> List[Dict]:
        """Obter lista de portas abertas"""
        success, output = self.run_command("netstat -tuln | grep LISTEN")
        ports = []
        
        if success:
            for line in output.split('\n'):
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 4:
                        addr_port = parts[3]
                        if ':' in addr_port:
                            port = addr_port.split(':')[-1]
                            try:
                                port_num = int(port)
                                protocol = parts[0].lower()
                                ports.append({
                                    'port': port_num,
                                    'protocol': protocol,
                                    'address': addr_port
                                })
                            except ValueError:
                                continue
        
        return sorted(ports, key=lambda x: x['port'])

    def get_active_services(self) -> List[Dict]:
        """Obter serviços ativos"""
        active_services = []
        
        for service_id, service_info in self.services.items():
            if self.check_port_status(service_info['port']):
                service_info['id'] = service_id
                service_info['active'] = True
                active_services.append(service_info.copy())
            else:
                service_info['active'] = False
        
        return active_services

    def download_proxy_script(self):
        """Baixar script do proxy"""
        print(f"{Colors.YELLOW}Baixando script do proxy...{Colors.END}")
        
        # Criar diretório se não existir
        os.makedirs(os.path.dirname(self.proxy_script), exist_ok=True)
        
        # Comando para baixar
        download_cmd = f"wget -O {self.proxy_script} https://raw.githubusercontent.com/modderajuda/websocketsecurity/main/F2/Modulos/proxydt"
        success, output = self.run_command(download_cmd)
        
        if success:
            # Dar permissão de execução
            os.chmod(self.proxy_script, 0o777)
            print(f"{Colors.GREEN}Script baixado com sucesso!{Colors.END}")
            self.log_message("Script do proxy baixado com sucesso")
            return True
        else:
            print(f"{Colors.RED}Erro ao baixar script: {output}{Colors.END}")
            self.log_message(f"Erro ao baixar script: {output}", "ERROR")
            return False

    def start_service(self, service_id: str) -> bool:
        """Iniciar serviço"""
        if service_id not in self.services:
            return False
        
        service = self.services[service_id]
        port = service['port']
        response = service['response']
        
        # Verificar se o script existe
        if not os.path.exists(self.proxy_script):
            print(f"{Colors.YELLOW}Script não encontrado. Baixando...{Colors.END}")
            if not self.download_proxy_script():
                return False
        
        # Verificar se a porta já está em uso
        if self.check_port_status(port):
            print(f"{Colors.YELLOW}Porta {port} já está em uso{Colors.END}")
            return False
        
        # Comando para iniciar o serviço
        cmd = f"screen -dmS {service_id} {self.proxy_script} --port {port} --http --openvpn-port --response {response}"
        
        success, output = self.run_command(cmd, capture_output=False)
        
        if success:
            time.sleep(2)  # Aguardar inicialização
            if self.check_port_status(port):
                service['active'] = True
                self.save_services()
                print(f"{Colors.GREEN}Serviço {service['name']} iniciado na porta {port}{Colors.END}")
                self.log_message(f"Serviço {service['name']} iniciado na porta {port}")
                return True
        
        print(f"{Colors.RED}Erro ao iniciar serviço {service['name']}{Colors.END}")
        self.log_message(f"Erro ao iniciar serviço {service['name']}", "ERROR")
        return False

    def stop_service(self, service_id: str) -> bool:
        """Parar serviço"""
        if service_id not in self.services:
            return False
        
        service = self.services[service_id]
        port = service['port']
        
        # Comando para parar o serviço
        cmd = f"sudo kill -9 $(lsof -t -i:{port}) 2>/dev/null"
        success, output = self.run_command(cmd)
        
        # Também tentar matar a sessão screen
        screen_cmd = f"screen -S {service_id} -X quit 2>/dev/null"
        self.run_command(screen_cmd)
        
        time.sleep(1)
        
        if not self.check_port_status(port):
            service['active'] = False
            self.save_services()
            print(f"{Colors.GREEN}Serviço {service['name']} parado{Colors.END}")
            self.log_message(f"Serviço {service['name']} parado")
            return True
        
        print(f"{Colors.RED}Erro ao parar serviço {service['name']}{Colors.END}")
        return False

    def change_port(self, service_id: str, new_port: int) -> bool:
        """Alterar porta do serviço"""
        if service_id not in self.services:
            return False
        
        service = self.services[service_id]
        old_port = service['port']
        was_active = service['active']
        
        # Parar serviço se estiver ativo
        if was_active:
            self.stop_service(service_id)
        
        # Alterar porta
        service['port'] = new_port
        self.save_services()
        
        # Reiniciar se estava ativo
        if was_active:
            return self.start_service(service_id)
        
        print(f"{Colors.GREEN}Porta do serviço {service['name']} alterada de {old_port} para {new_port}{Colors.END}")
        self.log_message(f"Porta do serviço {service['name']} alterada de {old_port} para {new_port}")
        return True

    def change_response(self, service_id: str, new_response: str) -> bool:
        """Alterar resposta do serviço"""
        if service_id not in self.services:
            return False
        
        service = self.services[service_id]
        old_response = service['response']
        was_active = service['active']
        
        # Parar serviço se estiver ativo
        if was_active:
            self.stop_service(service_id)
        
        # Alterar resposta
        service['response'] = new_response
        self.save_services()
        
        # Reiniciar se estava ativo
        if was_active:
            return self.start_service(service_id)
        
        print(f"{Colors.GREEN}Resposta do serviço {service['name']} alterada de {old_response} para {new_response}{Colors.END}")
        self.log_message(f"Resposta do serviço {service['name']} alterada de {old_response} para {new_response}")
        return True

    def clear_screen(self):
        """Limpar tela"""
        os.system('clear')

    def print_header(self):
        """Imprimir cabeçalho"""
        self.clear_screen()
        print(f"{Colors.CYAN}{Colors.BOLD}")
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║                    PROXY MANAGER v1.0                       ║")
        print("║              Sistema de Gerenciamento de Proxy              ║")
        print("║                    Ubuntu/Debian                             ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print(f"{Colors.END}")

    def print_menu(self):
        """Imprimir menu principal"""
        print(f"\n{Colors.BOLD}{Colors.WHITE}Menu Principal:{Colors.END}")
        print(f"{Colors.GREEN}1.{Colors.END} Ver Status dos Serviços")
        print(f"{Colors.GREEN}2.{Colors.END} Ver Portas Abertas")
        print(f"{Colors.GREEN}3.{Colors.END} Gerenciar Serviços")
        print(f"{Colors.GREEN}4.{Colors.END} Configurações")
        print(f"{Colors.GREEN}5.{Colors.END} Logs do Sistema")
        print(f"{Colors.GREEN}6.{Colors.END} Ferramentas")
        print(f"{Colors.RED}0.{Colors.END} Sair")
        print(f"\n{Colors.YELLOW}Escolha uma opção:{Colors.END} ", end="")

    def show_services_status(self):
        """Mostrar status dos serviços"""
        self.print_header()
        print(f"{Colors.BOLD}{Colors.WHITE}Status dos Serviços:{Colors.END}\n")
        
        active_services = self.get_active_services()
        
        print(f"{'ID':<15} {'Nome':<20} {'Porta':<8} {'Status':<12} {'Response'}")
        print("─" * 70)
        
        for service_id, service in self.services.items():
            status_color = Colors.GREEN if service['active'] else Colors.RED
            status_text = "ATIVO" if service['active'] else "INATIVO"
            
            print(f"{service_id:<15} {service['name']:<20} {service['port']:<8} "
                  f"{status_color}{status_text:<12}{Colors.END} {service['response']}")
        
        print(f"\n{Colors.CYAN}Total de serviços ativos: {len([s for s in self.services.values() if s['active']])}{Colors.END}")

    def show_open_ports(self):
        """Mostrar portas abertas"""
        self.print_header()
        print(f"{Colors.BOLD}{Colors.WHITE}Portas Abertas no Sistema:{Colors.END}\n")
        
        ports = self.get_open_ports()
        
        if not ports:
            print(f"{Colors.YELLOW}Nenhuma porta encontrada{Colors.END}")
            return
        
        print(f"{'Porta':<8} {'Protocolo':<12} {'Endereço'}")
        print("─" * 40)
        
        for port_info in ports:
            print(f"{port_info['port']:<8} {port_info['protocol']:<12} {port_info['address']}")
        
        print(f"\n{Colors.CYAN}Total de portas abertas: {len(ports)}{Colors.END}")

    def manage_services_menu(self):
        """Menu de gerenciamento de serviços"""
        while True:
            self.print_header()
            self.show_services_status()
            
            print(f"\n{Colors.BOLD}{Colors.WHITE}Gerenciar Serviços:{Colors.END}")
            print(f"{Colors.GREEN}1.{Colors.END} Iniciar Serviço")
            print(f"{Colors.GREEN}2.{Colors.END} Parar Serviço")
            print(f"{Colors.GREEN}3.{Colors.END} Reiniciar Serviço")
            print(f"{Colors.GREEN}4.{Colors.END} Alterar Porta")
            print(f"{Colors.GREEN}5.{Colors.END} Alterar Response")
            print(f"{Colors.GREEN}6.{Colors.END} Adicionar Novo Serviço")
            print(f"{Colors.RED}0.{Colors.END} Voltar")
            
            choice = input(f"\n{Colors.YELLOW}Escolha uma opção:{Colors.END} ")
            
            if choice == '1':
                self.start_service_interactive()
            elif choice == '2':
                self.stop_service_interactive()
            elif choice == '3':
                self.restart_service_interactive()
            elif choice == '4':
                self.change_port_interactive()
            elif choice == '5':
                self.change_response_interactive()
            elif choice == '6':
                self.add_service_interactive()
            elif choice == '0':
                break
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
                time.sleep(1)

    def start_service_interactive(self):
        """Iniciar serviço interativamente"""
        print(f"\n{Colors.BOLD}Iniciar Serviço:{Colors.END}")
        
        inactive_services = [sid for sid, sinfo in self.services.items() if not sinfo['active']]
        
        if not inactive_services:
            print(f"{Colors.YELLOW}Todos os serviços já estão ativos{Colors.END}")
            input("Pressione Enter para continuar...")
            return
        
        print("Serviços disponíveis:")
        for i, service_id in enumerate(inactive_services, 1):
            service = self.services[service_id]
            print(f"{Colors.GREEN}{i}.{Colors.END} {service['name']} (Porta: {service['port']})")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o serviço:{Colors.END} ")) - 1
            if 0 <= choice < len(inactive_services):
                service_id = inactive_services[choice]
                self.start_service(service_id)
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def stop_service_interactive(self):
        """Parar serviço interativamente"""
        print(f"\n{Colors.BOLD}Parar Serviço:{Colors.END}")
        
        active_services = [sid for sid, sinfo in self.services.items() if sinfo['active']]
        
        if not active_services:
            print(f"{Colors.YELLOW}Nenhum serviço está ativo{Colors.END}")
            input("Pressione Enter para continuar...")
            return
        
        print("Serviços ativos:")
        for i, service_id in enumerate(active_services, 1):
            service = self.services[service_id]
            print(f"{Colors.GREEN}{i}.{Colors.END} {service['name']} (Porta: {service['port']})")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o serviço:{Colors.END} ")) - 1
            if 0 <= choice < len(active_services):
                service_id = active_services[choice]
                self.stop_service(service_id)
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def restart_service_interactive(self):
        """Reiniciar serviço interativamente"""
        print(f"\n{Colors.BOLD}Reiniciar Serviço:{Colors.END}")
        
        active_services = [sid for sid, sinfo in self.services.items() if sinfo['active']]
        
        if not active_services:
            print(f"{Colors.YELLOW}Nenhum serviço está ativo{Colors.END}")
            input("Pressione Enter para continuar...")
            return
        
        print("Serviços ativos:")
        for i, service_id in enumerate(active_services, 1):
            service = self.services[service_id]
            print(f"{Colors.GREEN}{i}.{Colors.END} {service['name']} (Porta: {service['port']})")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o serviço:{Colors.END} ")) - 1
            if 0 <= choice < len(active_services):
                service_id = active_services[choice]
                print(f"{Colors.YELLOW}Reiniciando serviço...{Colors.END}")
                self.stop_service(service_id)
                time.sleep(2)
                self.start_service(service_id)
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def change_port_interactive(self):
        """Alterar porta interativamente"""
        print(f"\n{Colors.BOLD}Alterar Porta do Serviço:{Colors.END}")
        
        service_list = list(self.services.keys())
        
        print("Serviços disponíveis:")
        for i, service_id in enumerate(service_list, 1):
            service = self.services[service_id]
            status = "ATIVO" if service['active'] else "INATIVO"
            print(f"{Colors.GREEN}{i}.{Colors.END} {service['name']} (Porta atual: {service['port']}) - {status}")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o serviço:{Colors.END} ")) - 1
            if 0 <= choice < len(service_list):
                service_id = service_list[choice]
                new_port = int(input(f"{Colors.YELLOW}Nova porta:{Colors.END} "))
                
                if 1 <= new_port <= 65535:
                    self.change_port(service_id, new_port)
                else:
                    print(f"{Colors.RED}Porta inválida! Use uma porta entre 1 e 65535{Colors.END}")
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def change_response_interactive(self):
        """Alterar resposta interativamente"""
        print(f"\n{Colors.BOLD}Alterar Response do Serviço:{Colors.END}")
        
        service_list = list(self.services.keys())
        
        print("Serviços disponíveis:")
        for i, service_id in enumerate(service_list, 1):
            service = self.services[service_id]
            status = "ATIVO" if service['active'] else "INATIVO"
            print(f"{Colors.GREEN}{i}.{Colors.END} {service['name']} (Response atual: {service['response']}) - {status}")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o serviço:{Colors.END} ")) - 1
            if 0 <= choice < len(service_list):
                service_id = service_list[choice]
                new_response = input(f"{Colors.YELLOW}Nova response (sem espaços):{Colors.END} ").strip()
                
                if new_response and ' ' not in new_response:
                    self.change_response(service_id, new_response)
                else:
                    print(f"{Colors.RED}Response inválida! Não use espaços{Colors.END}")
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def add_service_interactive(self):
        """Adicionar novo serviço interativamente"""
        print(f"\n{Colors.BOLD}Adicionar Novo Serviço:{Colors.END}")
        
        try:
            service_id = input(f"{Colors.YELLOW}ID do serviço (ex: custom1):{Colors.END} ").strip()
            if not service_id or service_id in self.services:
                print(f"{Colors.RED}ID inválido ou já existe!{Colors.END}")
                input("Pressione Enter para continuar...")
                return
            
            name = input(f"{Colors.YELLOW}Nome do serviço:{Colors.END} ").strip()
            if not name:
                print(f"{Colors.RED}Nome é obrigatório!{Colors.END}")
                input("Pressione Enter para continuar...")
                return
            
            port = int(input(f"{Colors.YELLOW}Porta:{Colors.END} "))
            if not (1 <= port <= 65535):
                print(f"{Colors.RED}Porta inválida!{Colors.END}")
                input("Pressione Enter para continuar...")
                return
            
            response = input(f"{Colors.YELLOW}Response (sem espaços):{Colors.END} ").strip()
            if not response or ' ' in response:
                print(f"{Colors.RED}Response inválida!{Colors.END}")
                input("Pressione Enter para continuar...")
                return
            
            # Adicionar serviço
            self.services[service_id] = {
                "name": name,
                "active": False,
                "port": port,
                "response": response,
                "process_name": "proxydt"
            }
            
            self.save_services()
            print(f"{Colors.GREEN}Serviço adicionado com sucesso!{Colors.END}")
            
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")
        
        input("Pressione Enter para continuar...")

    def settings_menu(self):
        """Menu de configurações"""
        while True:
            self.print_header()
            print(f"{Colors.BOLD}{Colors.WHITE}Configurações:{Colors.END}\n")
            
            print(f"Porta padrão: {Colors.CYAN}{self.config['default_port']}{Colors.END}")
            print(f"Response padrão: {Colors.CYAN}{self.config['default_response']}{Colors.END}")
            print(f"Auto-iniciar: {Colors.CYAN}{'Sim' if self.config['auto_start'] else 'Não'}{Colors.END}")
            print(f"Log habilitado: {Colors.CYAN}{'Sim' if self.config['log_enabled'] else 'Não'}{Colors.END}")
            
            print(f"\n{Colors.BOLD}{Colors.WHITE}Opções:{Colors.END}")
            print(f"{Colors.GREEN}1.{Colors.END} Alterar porta padrão")
            print(f"{Colors.GREEN}2.{Colors.END} Alterar response padrão")
            print(f"{Colors.GREEN}3.{Colors.END} Toggle auto-iniciar")
            print(f"{Colors.GREEN}4.{Colors.END} Toggle log")
            print(f"{Colors.GREEN}5.{Colors.END} Resetar configurações")
            print(f"{Colors.RED}0.{Colors.END} Voltar")
            
            choice = input(f"\n{Colors.YELLOW}Escolha uma opção:{Colors.END} ")
            
            if choice == '1':
                try:
                    new_port = int(input(f"{Colors.YELLOW}Nova porta padrão:{Colors.END} "))
                    if 1 <= new_port <= 65535:
                        self.config['default_port'] = new_port
                        self.save_config()
                        print(f"{Colors.GREEN}Porta padrão alterada!{Colors.END}")
                    else:
                        print(f"{Colors.RED}Porta inválida!{Colors.END}")
                except ValueError:
                    print(f"{Colors.RED}Entrada inválida!{Colors.END}")
                time.sleep(1)
                
            elif choice == '2':
                new_response = input(f"{Colors.YELLOW}Nova response padrão:{Colors.END} ").strip()
                if new_response and ' ' not in new_response:
                    self.config['default_response'] = new_response
                    self.save_config()
                    print(f"{Colors.GREEN}Response padrão alterada!{Colors.END}")
                else:
                    print(f"{Colors.RED}Response inválida!{Colors.END}")
                time.sleep(1)
                
            elif choice == '3':
                self.config['auto_start'] = not self.config['auto_start']
                self.save_config()
                status = "habilitado" if self.config['auto_start'] else "desabilitado"
                print(f"{Colors.GREEN}Auto-iniciar {status}!{Colors.END}")
                time.sleep(1)
                
            elif choice == '4':
                self.config['log_enabled'] = not self.config['log_enabled']
                self.save_config()
                status = "habilitado" if self.config['log_enabled'] else "desabilitado"
                print(f"{Colors.GREEN}Log {status}!{Colors.END}")
                time.sleep(1)
                
            elif choice == '5':
                confirm = input(f"{Colors.RED}Resetar todas as configurações? (s/N):{Colors.END} ")
                if confirm.lower() == 's':
                    self.config = {
                        "default_port": 80,
                        "default_response": "ALFA-PROXY",
                        "auto_start": False,
                        "log_enabled": True
                    }
                    self.save_config()
                    print(f"{Colors.GREEN}Configurações resetadas!{Colors.END}")
                    time.sleep(1)
                    
            elif choice == '0':
                break
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
                time.sleep(1)

    def show_logs(self):
        """Mostrar logs do sistema"""
        self.print_header()
        print(f"{Colors.BOLD}{Colors.WHITE}Logs do Sistema:{Colors.END}\n")
        
        if not os.path.exists(self.log_file):
            print(f"{Colors.YELLOW}Nenhum log encontrado{Colors.END}")
            input("Pressione Enter para continuar...")
            return
        
        try:
            with open(self.log_file, 'r') as f:
                lines = f.readlines()
            
            # Mostrar últimas 50 linhas
            recent_lines = lines[-50:] if len(lines) > 50 else lines
            
            for line in recent_lines:
                line = line.strip()
                if '[ERROR]' in line:
                    print(f"{Colors.RED}{line}{Colors.END}")
                elif '[WARNING]' in line:
                    print(f"{Colors.YELLOW}{line}{Colors.END}")
                else:
                    print(line)
            
            if len(lines) > 50:
                print(f"\n{Colors.CYAN}Mostrando últimas 50 linhas de {len(lines)} total{Colors.END}")
                
        except Exception as e:
            print(f"{Colors.RED}Erro ao ler logs: {e}{Colors.END}")
        
        input("\nPressione Enter para continuar...")

    def tools_menu(self):
        """Menu de ferramentas"""
        while True:
            self.print_header()
            print(f"{Colors.BOLD}{Colors.WHITE}Ferramentas:{Colors.END}")
            print(f"{Colors.GREEN}1.{Colors.END} Baixar/Atualizar Script do Proxy")
            print(f"{Colors.GREEN}2.{Colors.END} Verificar Dependências")
            print(f"{Colors.GREEN}3.{Colors.END} Limpar Logs")
            print(f"{Colors.GREEN}4.{Colors.END} Status do Sistema")
            print(f"{Colors.GREEN}5.{Colors.END} Backup/Restore Configurações")
            print(f"{Colors.RED}0.{Colors.END} Voltar")
            
            choice = input(f"\n{Colors.YELLOW}Escolha uma opção:{Colors.END} ")
            
            if choice == '1':
                self.download_proxy_script()
                input("Pressione Enter para continuar...")
            elif choice == '2':
                self.check_dependencies()
                input("Pressione Enter para continuar...")
            elif choice == '3':
                self.clear_logs()
                input("Pressione Enter para continuar...")
            elif choice == '4':
                self.show_system_status()
                input("Pressione Enter para continuar...")
            elif choice == '5':
                self.backup_restore_menu()
            elif choice == '0':
                break
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
                time.sleep(1)

    def check_dependencies(self):
        """Verificar dependências do sistema"""
        print(f"{Colors.YELLOW}Verificando dependências...{Colors.END}\n")
        
        dependencies = [
            ('screen', 'screen --version'),
            ('lsof', 'lsof -v'),
            ('netstat', 'netstat --version'),
            ('wget', 'wget --version')
        ]
        
        for dep_name, check_cmd in dependencies:
            success, output = self.run_command(check_cmd)
            status = f"{Colors.GREEN}OK{Colors.END}" if success else f"{Colors.RED}FALTANDO{Colors.END}"
            print(f"{dep_name:<10} {status}")
            
            if not success:
                print(f"  {Colors.YELLOW}Para instalar: sudo apt-get install {dep_name}{Colors.END}")
        
        print(f"\n{Colors.CYAN}Verificação concluída{Colors.END}")

    def clear_logs(self):
        """Limpar logs"""
        if os.path.exists(self.log_file):
            confirm = input(f"{Colors.RED}Limpar todos os logs? (s/N):{Colors.END} ")
            if confirm.lower() == 's':
                try:
                    open(self.log_file, 'w').close()
                    print(f"{Colors.GREEN}Logs limpos com sucesso!{Colors.END}")
                except Exception as e:
                    print(f"{Colors.RED}Erro ao limpar logs: {e}{Colors.END}")
            else:
                print(f"{Colors.YELLOW}Operação cancelada{Colors.END}")
        else:
            print(f"{Colors.YELLOW}Nenhum log encontrado{Colors.END}")

    def show_system_status(self):
        """Mostrar status do sistema"""
        print(f"{Colors.BOLD}{Colors.WHITE}Status do Sistema:{Colors.END}\n")
        
        # Informações do sistema
        success, hostname = self.run_command("hostname")
        if success:
            print(f"Hostname: {Colors.CYAN}{hostname}{Colors.END}")
        
        success, uptime = self.run_command("uptime -p")
        if success:
            print(f"Uptime: {Colors.CYAN}{uptime}{Colors.END}")
        
        success, load = self.run_command("cat /proc/loadavg | cut -d' ' -f1-3")
        if success:
            print(f"Load Average: {Colors.CYAN}{load}{Colors.END}")
        
        # Informações de memória
        success, memory = self.run_command("free -h | grep Mem | awk '{print $3\"/\"$2}'")
        if success:
            print(f"Memória: {Colors.CYAN}{memory}{Colors.END}")
        
        # Informações de disco
        success, disk = self.run_command("df -h / | tail -1 | awk '{print $3\"/\"$2\" (\"$5\" usado)\"}'")
        if success:
            print(f"Disco /: {Colors.CYAN}{disk}{Colors.END}")
        
        print(f"\n{Colors.BOLD}Informações do Proxy Manager:{Colors.END}")
        print(f"Versão: {Colors.CYAN}1.0{Colors.END}")
        print(f"Config: {Colors.CYAN}{self.config_file}{Colors.END}")
        print(f"Services: {Colors.CYAN}{self.services_file}{Colors.END}")
        print(f"Logs: {Colors.CYAN}{self.log_file}{Colors.END}")
        print(f"Script: {Colors.CYAN}{self.proxy_script}{Colors.END}")

    def backup_restore_menu(self):
        """Menu de backup e restore"""
        while True:
            self.print_header()
            print(f"{Colors.BOLD}{Colors.WHITE}Backup/Restore:{Colors.END}")
            print(f"{Colors.GREEN}1.{Colors.END} Criar Backup")
            print(f"{Colors.GREEN}2.{Colors.END} Restaurar Backup")
            print(f"{Colors.GREEN}3.{Colors.END} Listar Backups")
            print(f"{Colors.RED}0.{Colors.END} Voltar")
            
            choice = input(f"\n{Colors.YELLOW}Escolha uma opção:{Colors.END} ")
            
            if choice == '1':
                self.create_backup()
                input("Pressione Enter para continuar...")
            elif choice == '2':
                self.restore_backup()
                input("Pressione Enter para continuar...")
            elif choice == '3':
                self.list_backups()
                input("Pressione Enter para continuar...")
            elif choice == '0':
                break
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
                time.sleep(1)

    def create_backup(self):
        """Criar backup das configurações"""
        backup_dir = "/etc/proxy-manager/backups"
        os.makedirs(backup_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = f"{backup_dir}/backup_{timestamp}.tar.gz"
        
        # Criar backup
        cmd = f"tar -czf {backup_file} -C /etc/proxy-manager config.json services.json 2>/dev/null"
        success, output = self.run_command(cmd)
        
        if success:
            print(f"{Colors.GREEN}Backup criado: {backup_file}{Colors.END}")
            self.log_message(f"Backup criado: {backup_file}")
        else:
            print(f"{Colors.RED}Erro ao criar backup{Colors.END}")

    def restore_backup(self):
        """Restaurar backup"""
        backup_dir = "/etc/proxy-manager/backups"
        
        if not os.path.exists(backup_dir):
            print(f"{Colors.YELLOW}Nenhum backup encontrado{Colors.END}")
            return
        
        # Listar backups
        backups = [f for f in os.listdir(backup_dir) if f.startswith("backup_") and f.endswith(".tar.gz")]
        backups.sort(reverse=True)
        
        if not backups:
            print(f"{Colors.YELLOW}Nenhum backup encontrado{Colors.END}")
            return
        
        print("Backups disponíveis:")
        for i, backup in enumerate(backups, 1):
            print(f"{Colors.GREEN}{i}.{Colors.END} {backup}")
        
        try:
            choice = int(input(f"\n{Colors.YELLOW}Escolha o backup:{Colors.END} ")) - 1
            if 0 <= choice < len(backups):
                backup_file = f"{backup_dir}/{backups[choice]}"
                
                confirm = input(f"{Colors.RED}Restaurar backup? Isso sobrescreverá as configurações atuais (s/N):{Colors.END} ")
                if confirm.lower() == 's':
                    cmd = f"tar -xzf {backup_file} -C /etc/proxy-manager"
                    success, output = self.run_command(cmd)
                    
                    if success:
                        print(f"{Colors.GREEN}Backup restaurado com sucesso!{Colors.END}")
                        # Recarregar configurações
                        self.config = self.load_config()
                        self.services = self.load_services()
                        self.log_message(f"Backup restaurado: {backup_file}")
                    else:
                        print(f"{Colors.RED}Erro ao restaurar backup{Colors.END}")
                else:
                    print(f"{Colors.YELLOW}Operação cancelada{Colors.END}")
            else:
                print(f"{Colors.RED}Opção inválida!{Colors.END}")
        except ValueError:
            print(f"{Colors.RED}Entrada inválida!{Colors.END}")

    def list_backups(self):
        """Listar backups"""
        backup_dir = "/etc/proxy-manager/backups"
        
        if not os.path.exists(backup_dir):
            print(f"{Colors.YELLOW}Nenhum backup encontrado{Colors.END}")
            return
        
        backups = [f for f in os.listdir(backup_dir) if f.startswith("backup_") and f.endswith(".tar.gz")]
        backups.sort(reverse=True)
        
        if not backups:
            print(f"{Colors.YELLOW}Nenhum backup encontrado{Colors.END}")
            return
        
        print(f"{Colors.BOLD}Backups disponíveis:{Colors.END}\n")
        
        for backup in backups:
            backup_path = f"{backup_dir}/{backup}"
            # Obter informações do arquivo
            success, file_info = self.run_command(f"ls -lh {backup_path}")
            if success:
                parts = file_info.split()
                if len(parts) >= 5:
                    size = parts[4]
                    date_time = " ".join(parts[5:8])
                    print(f"{Colors.CYAN}{backup}{Colors.END}")
                    print(f"  Tamanho: {size}")
                    print(f"  Data: {date_time}")
                    print()

    def run(self):
        """Executar o programa principal"""
        # Verificar se está executando como root
        if os.geteuid() != 0:
            print(f"{Colors.RED}Este programa deve ser executado como root (sudo){Colors.END}")
            sys.exit(1)
        
        # Auto-iniciar serviços se configurado
        if self.config.get('auto_start', False):
            print(f"{Colors.YELLOW}Auto-iniciando serviços...{Colors.END}")
            for service_id, service in self.services.items():
                if not service['active']:
                    self.start_service(service_id)
            time.sleep(2)
        
        while True:
            try:
                self.print_header()
                self.print_menu()
                
                choice = input().strip()
                
                if choice == '1':
                    self.show_services_status()
                    input("\nPressione Enter para continuar...")
                elif choice == '2':
                    self.show_open_ports()
                    input("\nPressione Enter para continuar...")
                elif choice == '3':
                    self.manage_services_menu()
                elif choice == '4':
                    self.settings_menu()
                elif choice == '5':
                    self.show_logs()
                elif choice == '6':
                    self.tools_menu()
                elif choice == '0':
                    print(f"\n{Colors.GREEN}Obrigado por usar o Proxy Manager!{Colors.END}")
                    self.log_message("Sistema encerrado pelo usuário")
                    break
                else:
                    print(f"{Colors.RED}Opção inválida!{Colors.END}")
                    time.sleep(1)
                    
            except KeyboardInterrupt:
                print(f"\n\n{Colors.YELLOW}Programa interrompido pelo usuário{Colors.END}")
                self.log_message("Sistema interrompido pelo usuário")
                break
            except Exception as e:
                print(f"\n{Colors.RED}Erro inesperado: {e}{Colors.END}")
                self.log_message(f"Erro inesperado: {e}", "ERROR")
                input("Pressione Enter para continuar...")

def main():
    """Função principal"""
    try:
        manager = ProxyManager()
        manager.run()
    except Exception as e:
        print(f"{Colors.RED}Erro fatal: {e}{Colors.END}")
        sys.exit(1)

if __name__ == "__main__":
    main()
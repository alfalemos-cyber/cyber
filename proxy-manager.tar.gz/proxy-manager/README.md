# Proxy Manager v1.0

Sistema completo de gerenciamento de proxy e serviços para Ubuntu/Debian com interface interativa no terminal.

## 📋 Características

- **Interface Interativa**: Menu completo no terminal com navegação intuitiva
- **Gerenciamento de Serviços**: Iniciar, parar, reiniciar serviços proxy
- **Monitoramento**: Visualização de portas abertas e serviços ativos
- **Configuração Flexível**: Alterar portas, responses e configurações facilmente
- **Sistema de Logs**: Log completo de todas as operações
- **Backup/Restore**: Sistema de backup e restauração de configurações
- **Auto-Start**: Opção de inicialização automática dos serviços
- **Multi-Serviços**: Suporte a proxy HTTP, WebSocket e WebSocket Security

## 🚀 Instalação Rápida

```bash
# Baixar o projeto
wget -O proxy-manager.tar.gz https://github.com/seu-usuario/proxy-manager/archive/main.tar.gz
tar -xzf proxy-manager.tar.gz
cd proxy-manager-main/

# Executar instalação
sudo chmod +x install.sh
sudo ./install.sh
```

## 📦 Instalação Manual

### 1. Clonar ou baixar o projeto

```bash
# Via Git
git clone https://github.com/seu-usuario/proxy-manager.git
cd proxy-manager

# Ou baixar e extrair manualmente
```

### 2. Executar script de instalação

```bash
sudo chmod +x install.sh
sudo ./install.sh
```

### 3. Executar o programa

```bash
sudo proxy-manager
```

## 🛠️ Requisitos do Sistema

### Sistemas Suportados
- Ubuntu 18.04+
- Debian 9+

### Dependências Automáticas
O script de instalação irá instalar automaticamente:
- Python 3
- Screen
- lsof
- net-tools
- wget
- curl

## 📖 Como Usar

### Executar o Programa

```bash
# Comando global (após instalação)
sudo proxy-manager

# Ou executar diretamente
sudo /usr/local/bin/proxy-manager
```

### Menu Principal

```
╔══════════════════════════════════════════════════════════════╗
║                    PROXY MANAGER v1.0                       ║
║              Sistema de Gerenciamento de Proxy              ║
║                    Ubuntu/Debian                             ║
╚══════════════════════════════════════════════════════════════╝

Menu Principal:
1. Ver Status dos Serviços
2. Ver Portas Abertas
3. Gerenciar Serviços
4. Configurações
5. Logs do Sistema
6. Ferramentas
0. Sair
```

### Principais Funcionalidades

#### 1. Status dos Serviços
- Visualizar todos os serviços configurados
- Status (ATIVO/INATIVO) de cada serviço
- Portas utilizadas
- Responses configuradas

#### 2. Portas Abertas
- Lista completa de portas abertas no sistema
- Protocolo (TCP/UDP)
- Endereços de bind

#### 3. Gerenciar Serviços
- **Iniciar Serviço**: Ativar serviços inativos
- **Parar Serviço**: Desativar serviços ativos
- **Reiniciar Serviço**: Reinicializar serviços
- **Alterar Porta**: Modificar porta de qualquer serviço
- **Alterar Response**: Modificar mensagem de resposta
- **Adicionar Novo Serviço**: Criar serviços personalizados

#### 4. Configurações
- Porta padrão para novos serviços
- Response padrão
- Auto-inicialização de serviços
- Habilitar/desabilitar logs

#### 5. Sistema de Logs
- Visualizar últimas 50 entradas de log
- Logs com timestamp e nível (INFO/ERROR/WARNING)
- Opção para limpar logs

#### 6. Ferramentas
- **Baixar/Atualizar Script**: Baixa a versão mais recente do proxydt
- **Verificar Dependências**: Verifica se todas as dependências estão instaladas
- **Status do Sistema**: Informações detalhadas do sistema
- **Backup/Restore**: Sistema completo de backup e restauração

## 🔧 Serviços Pré-Configurados

### Proxy HTTP (proxy)
- **Porta**: 80
- **Response**: ALFA-PROXY
- **Uso**: Proxy HTTP padrão

### WebSocket (websocket)
- **Porta**: 8080
- **Response**: WS-PROXY
- **Uso**: Proxy WebSocket

### WebSocket Security (websocket_secure)
- **Porta**: 443
- **Response**: WSS-PROXY
- **Uso**: Proxy WebSocket Seguro

## 📁 Estrutura de Arquivos

```
/usr/local/bin/proxy-manager          # Programa principal
/usr/bin/proxy-manager                 # Link simbólico para comando global
/etc/proxy-manager/                    # Diretório de configurações
├── config.json                       # Configurações principais
├── services.json                     # Configurações de serviços
├── proxydt                           # Script do proxy
├── backups/                          # Backups das configurações
└── uninstall.sh                      # Script de desinstalação
/var/log/proxy-manager.log            # Arquivo de log
/etc/systemd/system/proxy-manager.service  # Serviço systemd (opcional)
```

## 🔄 Comandos Equivalentes

O programa automatiza os seguintes comandos:

### Iniciar Serviço
```bash
# Comando manual
screen -dmS proxydt /etc/proxy-manager/proxydt --port 80 --http --openvpn-port --response ALFA-PROXY

# No programa
Menu → Gerenciar Serviços → Iniciar Serviço
```

### Parar Serviço
```bash
# Comando manual
sudo kill -9 $(lsof -t -i:80)

# No programa
Menu → Gerenciar Serviços → Parar Serviço
```

### Verificar Portas
```bash
# Comando manual
netstat -tuln | grep LISTEN

# No programa
Menu → Ver Portas Abertas
```

## ⚙️ Configuração Avançada

### Adicionar Serviço Personalizado

1. Acesse: Menu → Gerenciar Serviços → Adicionar Novo Serviço
2. Configure:
   - **ID**: Identificador único (ex: custom1)
   - **Nome**: Nome descritivo
   - **Porta**: Porta a ser utilizada
   - **Response**: Mensagem de resposta (sem espaços)

### Alterar Configurações Padrão

1. Acesse: Menu → Configurações
2. Opções disponíveis:
   - Porta padrão para novos serviços
   - Response padrão
   - Auto-inicialização
   - Sistema de logs

### Backup e Restore

```bash
# Criar backup
Menu → Ferramentas → Backup/Restore → Criar Backup

# Restaurar backup
Menu → Ferramentas → Backup/Restore → Restaurar Backup
```

## 🐛 Solução de Problemas

### Erro de Permissão
```bash
# Execute sempre como root
sudo proxy-manager
```

### Porta já está em uso
```bash
# Verificar que processo está usando a porta
sudo lsof -i:PORTA

# Parar processo específico
sudo kill -9 PID
```

### Script do proxy não encontrado
```bash
# Baixar manualmente via menu
Menu → Ferramentas → Baixar/Atualizar Script

# Ou baixar via comando
cd /etc/proxy-manager/
sudo wget https://raw.githubusercontent.com/modderajuda/websocketsecurity/main/F2/Modulos/proxydt
sudo chmod 777 proxydt
```

### Dependências faltando
```bash
# Verificar dependências
Menu → Ferramentas → Verificar Dependências

# Instalar manualmente
sudo apt-get update
sudo apt-get install python3 screen lsof net-tools wget
```

## 🔧 Desinstalação

### Método 1: Script automático
```bash
sudo /etc/proxy-manager/uninstall.sh
```

### Método 2: Manual
```bash
# Parar todos os serviços
sudo pkill -f proxydt

# Remover arquivos
sudo rm -f /usr/local/bin/proxy-manager
sudo rm -f /usr/bin/proxy-manager
sudo rm -f /etc/systemd/system/proxy-manager.service

# Remover configurações (opcional)
sudo rm -rf /etc/proxy-manager/

# Remover logs (opcional)
sudo rm -f /var/log/proxy-manager.log
```

## 📊 Exemplos de Uso

### Cenário 1: Proxy HTTP Básico
```
1. Executar: sudo proxy-manager
2. Menu → Gerenciar Serviços → Iniciar Serviço
3. Escolher: Proxy HTTP (porta 80)
4. Verificar status: Menu → Ver Status dos Serviços
```

### Cenário 2: WebSocket na Porta 8080
```
1. Menu → Gerenciar Serviços → Alterar Porta
2. Escolher: WebSocket
3. Nova porta: 8080
4. Menu → Gerenciar Serviços → Iniciar Serviço
```

### Cenário 3: Múltiplos Serviços
```
1. Iniciar Proxy HTTP na porta 80
2. Iniciar WebSocket na porta 8080
3. Iniciar WebSocket Security na porta 443
4. Verificar: Menu → Ver Portas Abertas
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## ✨ Changelog

### v1.0.0 (2024-01-01)
- Lançamento inicial
- Interface interativa completa
- Sistema de gerenciamento de serviços
- Monitoramento de portas
- Sistema de logs
- Backup/Restore
- Auto-instalação

## 📞 Suporte

- **Issues**: [GitHub Issues](https://github.com/seu-usuario/proxy-manager/issues)
- **Wiki**: [GitHub Wiki](https://github.com/seu-usuario/proxy-manager/wiki)
- **Discussões**: [GitHub Discussions](https://github.com/seu-usuario/proxy-manager/discussions)

## 🙏 Agradecimentos

- Comunidade Ubuntu/Debian
- Desenvolvedores do projeto original websocketsecurity
- Contribuidores do projeto

---

**Proxy Manager v1.0** - Sistema de Gerenciamento de Proxy para Ubuntu/Debian